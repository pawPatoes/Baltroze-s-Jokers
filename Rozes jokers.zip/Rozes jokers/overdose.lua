local mod = SMODS.current_mod
local items_path = mod.path .. "items/"
local item_files = NFS.getDirectoryItems(items_path)

for _, file in ipairs(item_files) do
    if file:match("%.lua$") then
        local file_content = NFS.read(items_path .. file)
        local func, err = loadstring(file_content, file)
        if func then
            pcall(func)
            print("Rose: Loaded " .. file)
        else
            print("Error loading " .. file .. ": " .. tostring(err))
            error(err)
        end
    end
end
SMODS.Atlas {key = "sprite", path = "sprite.png", px = 71, py = 95}
mod.optional_features = {  
    retrigger_joker = true  
}