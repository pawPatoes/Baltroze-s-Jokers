SMODS.Joker {
    key = 'ultimo',
    loc_txt = {
        name = 'Ultimo',
        text = {
            "Retrigger all",
            "{C:attention}Jokers{}"
        }
    },
    config = { extra = { repetitions = 1 } },
    rarity = 4,
    cost = 20,
    atlas = 'sprite',
    pos = { x = 3, y = 1 },
    blueprint_compat = true,
    discovered = true,
    calculate = function(self, card, context)
        if context.retrigger_joker_check and context.other_card ~= card then
            return {
                message = localize('k_again_ex'),
                repetitions = card.ability.extra.repetitions,
                card = card
            }
        end
    end
}