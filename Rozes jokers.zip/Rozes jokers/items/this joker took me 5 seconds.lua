SMODS.Joker {
    key = 'gourmand',
    loc_txt = {
        name = 'Gourmand',
        text = {
            "{C:attention}+#1#{} consumable slot"
        }
    },
    config = { extra = { slots = 1 } },
    rarity = 1,
    cost = 4,
    atlas = 'sprite',
    pos = { x = 2, y = 1 },
    blueprint_compat = false,
    discovered = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.slots } }
    end,
    add_to_deck = function(self, card, from_debuff)
        G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.slots
    end,
    remove_from_deck = function(self, card, from_debuff)
        G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.slots
    end
}