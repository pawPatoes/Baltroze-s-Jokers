SMODS.Joker {
    key = 'till',
    loc_txt = {
        name = 'Till Eulenspiegel',
        text = {
            "When sold, Resets",
            "{C:attention}EVERYTHING{} except",
            "{C:attention}Jokers{}, {C:purple}Vouchers{} and",
            "{C:green}Consumables{}",
            "{C:inactive}(This Joker can't be duplicated)"
        }
    },
    config = {},
    rarity = 4,
    cost = 20,
    atlas = 'sprite',
    pos = { x = 0, y = 1 },
    soul_pos = { x = 0, y = 1 },
    blueprint_compat = false,
    discovered = true,
    unlocked = false,
    calculate = function(self, card, context)
        if context.selling_self and not context.blueprint then
            local debt = -card.sell_cost + 4
            G.E_MANAGER:add_event(Event({
                func = function()
                    G.GAME.round_resets.ante = 1
                    G.GAME.round_resets.hands = G.GAME.starting_params.hands
                    G.GAME.round_resets.discards = G.GAME.starting_params.discards
                    G.GAME.dollars = debt
                    G.GAME.round = 0
                    G.GAME.current_round.hands_played = 0
                    G.GAME.current_round.discards_used = 0
                    return true
                end
            }))
            return {
                message = 'Reset!',
                colour = G.C.FILTER
            }
        end
    end
}