SMODS.Joker {
    key = 'wild_joker',
    loc_txt = {
        name = 'Wild Joker',
        text = {
            "Retrigger all played",
            "{C:attention}#1#{} cards,",
            "suit changes at",
            "end of round"
        },
        unlock = {
            "Play all 4 {C:attention}suits",
            "In one {C:attention}hand{}"
        }
    },
    config = { extra = { suit = 'Spades' } },
    rarity = 2,
    cost = 6,
    atlas = 'sprite',
    check_for_unlock = function(self, args)
        if args.type == 'play_all_suits' then
            return true
        end
        if args.type == 'hand_contents' then
            local suits_in_hand = {}
            for i = 1, #args.cards do
                local suit = args.cards[i].base.suit
                suits_in_hand[suit] = true
            end
            local count = 0
            for _ in pairs(suits_in_hand) do count = count + 1 end
            if count >= 4 then
                unlock_card(self)
            end
        end
    end,
    pos = { x = 1, y = 0 },
    discovered = false,
    unlocked = false,
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.suit } }
    end,
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play then
            if context.other_card:is_suit(card.ability.extra.suit) then
                return {
                    message = 'Again!',
                    repetitions = 1,
                    card = card
                }
            end
        end
        if context.end_of_round and not context.blueprint and not context.repetition and not context.individual then
            local suits = {'Spades', 'Hearts', 'Clubs', 'Diamonds'}
            pcall(function()
                if G.P_SUITS then
                    local game_suits = {}
                    for k, v in pairs(G.P_SUITS) do
                        table.insert(game_suits, k)
                    end
                    if #game_suits > 0 then suits = game_suits end
                end
            end)
            local current_suit = card.ability.extra.suit
            local new_suit = current_suit
            while new_suit == current_suit do
                new_suit = suits[math.random(#suits)]
            end
            card.ability.extra.suit = new_suit
            return {
                message = card.ability.extra.suit .. '!',
                colour = G.C.FILTER
            }
        end
    end
}