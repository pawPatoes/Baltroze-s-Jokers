local function override_arcana_booster(most_used_tarot)  
    if not SMODS.OPENED_BOOSTER then return end  
      
    local booster_key = SMODS.OPENED_BOOSTER.config.center.key  
    if booster_key:lower():find('arcana') then  
        local original_create_card = SMODS.OPENED_BOOSTER.config.center.create_card  
        local already_set = false  
          
        SMODS.OPENED_BOOSTER.config.center.create_card = function(self, card, i)  
            if not already_set then  
                already_set = true  
                return {set = "Tarot", area = G.pack_cards, skip_materialize = true, soulable = true, key = most_used_tarot, key_append = "ar1"}  
            else  
                return original_create_card(self, card, i)  
            end  
        end  
    end  
end  
  
local function get_most_used_tarot()  
    local most_used_tarot = "c_fool"  
    local max_uses = -1  
      
    local usage_table = G.PROFILES[G.SETTINGS.profile].consumeable_usage  
    for k, v in pairs(G.P_CENTERS) do  
        if v.set == 'Tarot' then  
            local count = usage_table[k] and usage_table[k].count or 0  
            if count > max_uses then  
                max_uses = count  
                most_used_tarot = k  
            end  
        end  
    end  
    return most_used_tarot  
end  
  
SMODS.Joker {  
    key = 'wish',  
    loc_txt = {  
        name = 'Wishing Well',  
        text = {  
            "{C:attention}Arcana Packs{} always",  
            "contain your most used",  
            "{C:tarot}Tarot{} card"  
        },
        unlock = {
            "Use {C:tarot}10{} Tarot cards",
            "in a single run"
        }  
    },  
    discovered = false,
    unlocked = false,
    config = {},  
    check_for_unlock = function(self, args)  
        if args.type == 'tarot_used' then  
            local tarot_usage = 0  
            for k, v in pairs(G.GAME.consumeable_usage) do  
                local card_def = G.P_CENTERS[k]  
                if card_def and card_def.set == 'Tarot' then  
                    tarot_usage = tarot_usage + v.count  
                end  
            end  
            if tarot_usage >= 10 then  
                return true
            end  
        end  
    end,
    rarity = 2,  
    cost = 5,  
    atlas = 'sprite',  
    pos = { x = 0, y = 0 },  
    calculate = function(self, card, context)  
        if context.open_booster and SMODS.OPENED_BOOSTER then  
            local most_used_tarot = get_most_used_tarot()  
            override_arcana_booster(most_used_tarot)  
            return { message = "Set!" }  
        end  
    end  
}
local original_use_consumeable = Card.use_consumeable  
function Card:use_consumeable(area, copier)  
    local ret = original_use_consumeable(self, area, copier)  
    if self.ability.set == 'Tarot' then  
        local wish_def = G.P_CENTERS['j_rz_wish']
        if wish_def and not wish_def.unlocked then
            local tarot_usage = 0
            for k, v in pairs(G.GAME.consumeable_usage) do
                local card_def = G.P_CENTERS[k]
                if card_def and card_def.set == 'Tarot' then
                    tarot_usage = tarot_usage + v.count
                end
            end
            if tarot_usage >= 10 then
                unlock_card(wish_def)
            end
        end
    end  
    return ret  
end