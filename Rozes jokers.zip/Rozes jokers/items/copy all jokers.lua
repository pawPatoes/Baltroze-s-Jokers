local juicing_last_hand = false
SMODS.Joker {
    key = 'rna',
    loc_txt = {
        name = 'RNA',
        text = {
            "If {C:attention}last hand{} of round",
            "has only {C:attention}1 card{}, create",
            "a {C:dark_edition}Polychrome{} copy and",
            "add it to your {C:attention}deck{}"
        },
        unlock = {
            "Have {C:attention}5{} or more",
            "{C:dark_edition}Polychrome{} cards",
            "in your deck"
        }
    },
    config = {},
    rarity = 2,
    cost = 7,
    atlas = 'sprite',
    pos = { x = 2, y = 0 },
    discovered = false,
    unlocked = false,
    check_for_unlock = function(self, args)
        local polychrome_count = 0
        if G.playing_cards then
            for _, v in ipairs(G.playing_cards) do
                if v.edition and v.edition.polychrome then
                    polychrome_count = polychrome_count + 1
                end
            end
        end
        if polychrome_count >= 5 then
            return true
        end
    end,
    update = function(self, card)
        if G.GAME and G.GAME.current_round.hands_left == 1 and not juicing_last_hand then
            juicing_last_hand = true
            juice_card_until(card, function() 
                local should_keep_juicing = G.GAME.current_round.hands_left == 1 and G.STATE ~= G.STATES.ROUND_EVAL
                if not should_keep_juicing then juicing_last_hand = false end
                return should_keep_juicing
            end, true)
        end
    end,
    blueprint_compat = true,
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.before and G.GAME.current_round.hands_left == 0 then
            if context.full_hand and #context.full_hand == 1 then
                local _card = context.full_hand[1]
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local copy = copy_card(_card, nil, nil, nil, _card.edition)
                        copy:set_edition({polychrome = true}, true, true)
                        copy:add_to_deck()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        table.insert(G.playing_cards, copy)
                        G.deck:emplace(copy)
                        copy:start_materialize()
                        _card:juice_up()
                        return true
                    end
                }))
                return {
                    message = "Copied!",
                    colour = G.C.DARK_EDITION
                }
            end
        end
    end
}