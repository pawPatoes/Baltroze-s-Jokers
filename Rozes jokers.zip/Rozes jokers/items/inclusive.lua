-- Global function to handle Indecisive Joker logic
function indecisive_logic(card, context)
    card.rz_data = card.rz_data or { history = {}, current_joker_key = 'j_joker', current_joker_name = 'Joker' }
    if card.rz_calculating then return end
    if context.before and not context.blueprint then
        local valid_jokers = {}
        for k, v in pairs(G.P_CENTERS) do
            if v.set == 'Joker' and v.key ~= 'j_rz_indecisive' and v.key ~= 'j_DJ_err' and v.discovered and not v.locked then
                local played_before = false
                for _, history_key in ipairs(card.rz_data.history) do
                    if history_key == k then played_before = true; break end
                end
                if not played_before then table.insert(valid_jokers, k) end
            end
        end
        if #valid_jokers == 0 then
            card.rz_data.history = {}
            for k, v in pairs(G.P_CENTERS) do
                if v.set == 'Joker' and v.key ~= 'j_rz_indecisive' and v.key ~= 'j_DJ_err' and v.discovered and not v.locked then 
                    table.insert(valid_jokers, k) 
                end
            end
        end
        local new_joker_key = valid_jokers[pseudorandom('indecisive', 1, #valid_jokers)]
        local target = G.P_CENTERS[new_joker_key]
        local current_center = G.P_CENTERS[card.rz_data.current_joker_key]
        if current_center and current_center.remove_from_deck then
            pcall(function() current_center:remove_from_deck(card, false) end)
        end
        card.rz_data.current_joker_key = new_joker_key
        card.rz_data.current_joker_name = target.name or (target.loc_txt and target.loc_txt.name) or "Joker"
        table.insert(card.rz_data.history, new_joker_key)
        if target.config and target.config.extra then
            card.ability.extra = copy_table(target.config.extra)
        end
        if target.add_to_deck then
            pcall(function() target:add_to_deck(card, false) end)
        end

        return {
            message = tostring(card.rz_data.current_joker_name) .. '!',
            colour = G.C.FILTER
        }
    end
    local target_def = G.P_CENTERS[card.rz_data.current_joker_key]
    if target_def and target_def.calculate and type(target_def.calculate) == 'function' then
        card.rz_calculating = true
        local res = target_def:calculate(card, context)
        card.rz_calculating = nil
        if res then return res end
    end
    if context.selling_self and not context.blueprint then
        local key_to_spawn = card.rz_data.current_joker_key or 'j_joker'
        G.E_MANAGER:add_event(Event({
            func = function()
                local new_card = create_card('Joker', G.jokers, nil, nil, nil, nil, key_to_spawn)
                new_card:add_to_deck()
                G.jokers:emplace(new_card)
                return true
            end
        }))
    end
end

SMODS.Joker {
    key = 'indecisive',
    loc_txt = {
        name = 'Indecisive Joker',
        text = {
            "Turns into a random, non-",
            "repeating {C:attention}discovered Joker{} every",
            "{C:attention}hand played{}. Sell this card to",
            "create the {C:attention}Joker{} last copied.",
            "{C:inactive}(Currently: {C:attention}#1#{C:inactive})",
            "{C:red,s:0.8}Very Buggy!"
        }
    },
    config = { extra = {} }, 
    rarity = 3, 
    cost = 8, 
    atlas = 'sprite', 
    pos = { x = 4, y = 0 },
    blueprint_compat = true,
    loc_vars = function(self, info_queue, card)
        return { vars = { (card.rz_data and card.rz_data.current_joker_name) or "None" } }
    end,
    calculate = function(self, card, context)
        return indecisive_logic(card, context)
    end
}