local evaluate_play_ref = G.FUNCS.evaluate_play  
G.FUNCS.evaluate_play = function(e)  
    local cards = G.play.cards
    local rank_count = 0  
    for _, v in ipairs(cards) do  
        if v and v:get_id() == 11 then  
            rank_count = rank_count + 1  
        end  
    end  
  
    if rank_count >= 5 then  
        local center = G.P_CENTERS['j_rz_of_all_trades']  
        if center and not center.unlocked then  
            unlock_card(center)  
        end  
    end  
  
    return evaluate_play_ref(e)  
end

SMODS.Joker {
    key = 'of_all_trades',
    loc_txt = {
        name = 'Of All Trades',
        text = {
            "Gives {X:mult,C:white} X#1# {} Mult if you have played",
            "{C:attention}#2#{} different consecutive poker hands",
            "that each contain a {C:attention}#3#{}",
            "{C:inactive}(Streak: #4#/#2#)"
        },
        unlock = {
            "Play a hand with",
            "at least {C:attention}5 Jacks{}"
        }
    },
    config = { 
        extra = { 
            gain = 5, 
            streak_goal = 5, 
            required_id = 11, 
            required_rank = 'Jack',
            streak = {}, 
            streak_count = 0,
            streak_complete = false
        } 
    },
    rarity = 3,
    cost = 10,
    atlas = 'sprite',
    pos = { x = 3, y = 0 },
    discovered = true,
    unlocked = false,
    blueprint_compat = true,
    loc_vars = function(self, info_queue, card)
        local display_count = card.ability.extra.streak_count
        if card.ability.extra.streak_complete then display_count = card.ability.extra.streak_goal end
        return { 
            vars = { 
                card.ability.extra.gain, 
                card.ability.extra.streak_goal, 
                card.ability.extra.required_rank, 
                display_count
            } 
        }
    end,
    scoring = function(self, context)
        if self.ability.extra.streak_complete then
            return {
                Xmult = self.ability.extra.gain
            }
        end
    end,
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.before and not context.blueprint then
            if not card.ability.extra.streak_complete then
                local has_required_rank = false
                for k, v in ipairs(context.full_hand or {}) do
                    if v and v:get_id() == card.ability.extra.required_id then 
                        has_required_rank = true
                        break
                    end
                end

                local hand_type = context.scoring_name
                local is_new_type = true
                for _, v in ipairs(card.ability.extra.streak or {}) do
                    if v == hand_type then
                        is_new_type = false
                        break
                    end
                end

                if has_required_rank and is_new_type then
                    table.insert(card.ability.extra.streak, hand_type)
                    card.ability.extra.streak_count = #card.ability.extra.streak
                    
                    if card.ability.extra.streak_count >= card.ability.extra.streak_goal then
                        card.ability.extra.streak_complete = true
                        return {
                            message = 'X' .. card.ability.extra.gain .. ' Active!',
                            colour = G.C.MULT
                        }
                    else
                        return {
                            message = card.ability.extra.streak_count .. '/' .. card.ability.extra.streak_goal,
                            colour = G.C.ATTENTION
                        }
                    end
                else
                    if card.ability.extra.streak_count > 0 then
                        card.ability.extra.streak = {}
                        card.ability.extra.streak_count = 0
                        return {
                            message = 'Reset!',
                            colour = G.C.RED
                        }
                    end
                end
            end
        end
    end
}