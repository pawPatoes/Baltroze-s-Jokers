SMODS.Joker {  
    key = 'anarchist',  
    loc_txt = {  
        name = 'Anarchist',  
        text = {  
            "Each scored {C:attention}2{}, {C:attention}3{}, {C:attention}4{} or {C:attention}5{}",  
            "gives {X:mult,C:white}X#1#{} Mult.",  
            "{C:attention}Face{} cards are",  
            "{C:red}debuffed{}."  
        },  
        unlock = {  
            "Win a run without",  
            "any {C:attention}Face cards{} in",  
            "your deck"  
        }  
    },  
    config = { extra = { x_mult = 1.5 } },  
    rarity = 3,  
    cost = 8,  
    atlas = 'sprite',  
    pos = { x = 1, y = 1 },  
    blueprint_compat = true,  
    discovered = true,  
    unlocked = false,  
      
    joker_buffs = {  
        apply = function(self, card, context)  
            if G.playing_cards then  
                for _, v in pairs(G.playing_cards) do  
                    if v:is_face() then   
                        SMODS.debuff_card(v, true, 'anarchist_joker')  
                        SMODS.recalc_debuff(v)
                    end  
                end  
            end  
        end,  
        remove = function(self, card, context)  
            if G.playing_cards then  
                for _, v in pairs(G.playing_cards) do  
                        v.ability.debuff_sources = v.ability.debuff_sources or {}  
                        v.ability.debuff_sources['anarchist_joker'] = nil  
                        SMODS.recalc_debuff(v)  
                end  
            end  
        end  
    },  
      
    calculate = function(self, card, context)  
        if context.individual and context.cardarea == G.play then  
            local rank = context.other_card:get_id()  
            if rank >= 2 and rank <= 5 then  
                return {  
                    x_mult = card.ability.extra.x_mult,  
                    card = card  
                }  
            end  
        end  
        if context.recalc_debuff then  
            if context.other_card:is_face() then  
                return true  
            end  
        end  
    end,  
      
    check_for_unlock = function(self, args)  
        if args.type == 'win' then  
            local face_found = false  
            for k, v in pairs(G.playing_cards) do  
                if v:is_face() then   
                    face_found = true  
                    break   
                end  
            end  
            if not face_found then  
                return {unlock = true}  
            end  
        end  
    end,  
      
    loc_vars = function(self, info_queue, card)  
        return { vars = { card.ability.extra.x_mult } }  
    end  
}